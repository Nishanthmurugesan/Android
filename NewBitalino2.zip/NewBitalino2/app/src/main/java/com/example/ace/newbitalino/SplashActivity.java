package com.example.ace.newbitalino;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import ceu.marten.bitadroid.R;
import ceu.marten.ui.DrHome;
import ceu.marten.ui.HomeActivity;
import ceu.marten.ui.Login;

public class SplashActivity extends AppCompatActivity {
    public  static final String MyPreferences="MyBioPref";
    public  static final String userPref="userPref";
    public  static final String passPref="passPref";
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
requestWindowFeature(Window.FEATURE_NO_TITLE);
getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        ActionBar actionBar=getSupportActionBar();
        if(actionBar!=null){
            actionBar.hide();
        }
        final Intent intent;
        sharedPreferences=getSharedPreferences(MyPreferences, Context.MODE_PRIVATE);
        if(!sharedPreferences.getString(userPref,"").isEmpty()){
            String user=sharedPreferences.getString(userPref,""),pass=sharedPreferences.getString(passPref,"");
            if(user.equals("Doctor")&&pass.equals("dr123")){
                intent=new Intent(SplashActivity.this,DrHome.class);

            }else{
                intent=new Intent(SplashActivity.this,HomeActivity.class);
            }
            System.out.println("USERNAME: "+sharedPreferences.getString(userPref,"")+"##########");

        }else{
          intent=new Intent(SplashActivity.this,Login.class);

        }
                Thread t=new Thread(){
            public void run() {
                try {
                    Thread.sleep(2000); // As I am using LENGTH_LONG in Toast
                    startActivity(intent);
                    finish();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        t.start();

    }
}
