package com.example.ace.newbitalino;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by User on 06-02-2018.
 */

public class SaveUser extends SQLiteOpenHelper {
    public SaveUser(Context context) {
        super(context, "db", null,12);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table tbl_user (user text,pass text,phone text,dob text,blood text,gen text,phone1 text,phone2 text)");
        db.execSQL("create table tbl_seizures(status text)");
        db.execSQL("create table tbl_graph(user text,time text)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists tbl_user");
        db.execSQL("drop table if exists tbl_seizures");
db.execSQL("drop table if exists tbl_graph");
        onCreate(db);
    }
public int  register(String user,String pass,String phone,String dob,String blood,String gen,String phone1,String phone2){
     try {

         SQLiteDatabase db=getWritableDatabase();
         SQLiteDatabase db1=getWritableDatabase();
         Cursor c=db1.rawQuery("select user from tbl_user where user ='"+user+"'",null);
         ContentValues cv=new ContentValues();
         if(c.getCount()>0){
             return 1;
         }else{
             cv.put("user",user);
             cv.put("pass",pass);
             cv.put("phone",phone);
             cv.put("dob",dob);
             cv.put("blood",blood);
             cv.put("gen",gen);
             cv.put("phone1",phone1);
             cv.put("phone2",phone2);

             db.insert("tbl_user",null,cv);

             return 0;
         }

     }catch (Exception e){
         e.printStackTrace();
     return -1;
     }
}
    public int loginCheck(String luser,String lpwd){
        SQLiteDatabase db=getReadableDatabase();
        String[] args={luser,lpwd};
        Cursor c=db.query("tbl_user",null,"user=? and pass=?",args,null,null,null);
        return c.getCount();
    }
    public void setStatus(String str){
        SQLiteDatabase db=getWritableDatabase();
        db.rawQuery("delete from tbl_seizures",null);
        ContentValues cv=new ContentValues();
        cv.put("status",str);
        db.insert("tbl_seizures",null,cv);
System.out.println("###################"+str+" is Inserted!");
    }
    public int getStatus(){
        SQLiteDatabase db=getReadableDatabase();
Cursor c=db.rawQuery("select  * from tbl_seizures",null);

return c.getCount();
    }

    public void setEpiTime(String user,String time){
        SQLiteDatabase db=getWritableDatabase();
        SQLiteDatabase db1=getReadableDatabase();
        Cursor c=db1.rawQuery("select * from tbl_graph where user='"+user+"'",null);
        ContentValues cv=new ContentValues();
        cv.put("time",time);
        cv.put("user",user);
        if(c.getCount()>0){
        db.execSQL("delete from tbl_graph where user='"+user+"'");
            db.insert("tbl_graph",null,cv);
        }else{
            db.insert("tbl_graph",null,cv);
        }
    }
public  String getEpiTime(String user){
        SQLiteDatabase db=getReadableDatabase();
        Cursor c=db.rawQuery("select * from tbl_graph where user='"+user+"'",null);
        if(c.getCount()>0){
            c.moveToNext();
            return c.getString(c.getColumnIndex("time"));
        }else{
           return "null";
        }
}

}
