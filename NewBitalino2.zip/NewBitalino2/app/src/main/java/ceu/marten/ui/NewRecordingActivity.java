package ceu.marten.ui;

import java.sql.Array;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import ceu.marten.bitadroid.R;
import ceu.marten.model.Constants;
import ceu.marten.model.DeviceConfiguration;
import ceu.marten.model.DeviceRecording;
import ceu.marten.model.io.DataManager;
import ceu.marten.model.io.DatabaseHelper;
import ceu.marten.services.BiopluxService;

import com.example.ace.newbitalino.SaveUser;
import com.j256.ormlite.android.apptools.OrmLiteBaseActivity;
import com.j256.ormlite.dao.Dao;
import com.jjoe64.graphview.GraphView.GraphViewData;

/**
 * Used to record a session based on a configuration and display the
 * corresponding channels or if only one is to be displayed it shows the
 * configuration' details. Connects to a Bioplux service
 *
 * @author Carlos Marten
 *
 */
public class NewRecordingActivity extends OrmLiteBaseActivity<DatabaseHelper> implements android.widget.PopupMenu.OnMenuItemClickListener, OnSharedPreferenceChangeListener, LocationListener {
	int counter = 0;
	Timer timer;
	String MessageText;
	Button  Recovered;
	public static final String MyPreferences = "MyBioPref";
	public static final String userPref = "userPref";


	private static final String TAG = NewRecordingActivity.class.getName();
	// Keys used for communication with activity
	public static final String KEY_DURATION = "duration";
	public static final String KEY_RECORDING_NAME = "recordingName";
	public static final String KEY_CONFIGURATION = "configSelected";
	// key for recovery. Used when android kills activity
	public static final String KEY_CHRONOMETER_BASE = "chronometerBase";

	// 10 seconds
	private final int maxDataCount = 10000;
long toastCount=0;
	// Android's widgets
	private TextView uiRecordingName, uiConfigurationName, uiNumberOfBits,
			uiReceptionFrequency, uiSamplingFrequency, uiActiveChannels,
			uiMacAddress;
	private Button uiMainbutton;
	private Chronometer chronometer;

	// DIALOGS
	private AlertDialog connectionErrorDialog;
	private ProgressDialog savingDialog;

	// AUX VARIABLES
	private Context classContext = this;
	private Bundle extras;
	private LayoutInflater inflater;

	private DeviceConfiguration recordingConfiguration;
	private DeviceRecording recording;

	private Graph[] graphs;
	private int[] displayChannelPosition;
	private int currentZoomValue = 0;
	private String duration = null;
	private SharedPreferences sharedPref = null;

	private boolean isServiceBounded = false;
	private boolean recordingOverride = false;
	private boolean savingDialogMessageChanged = false;
	private boolean closeRecordingActivity = false;
	private boolean drawState = true; //true -> Enable | false -> Disable
	private boolean goToEnd = true;

	// ERROR VARIABLES
	private int bpErrorCode = 0;
	private boolean serviceError = false;
	private boolean connectionError = false;
	private double LAT, LNG;
	// MESSENGERS USED TO COMMUNICATE ACTIVITY AND SERVICE
	private Messenger serviceMessenger = null;
	private final Messenger activityMessenger = new Messenger(new IncomingHandler());
	private LocationManager locationManager;
	private Location location;

	/**
	 * Listener for new started touches on graphs vertical labels
	 */


	private OnTouchListener graphTouchListener = new OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			// get masked (not specific to a pointer) action
			int maskedAction = event.getActionMasked();

			switch (maskedAction) {
				case MotionEvent.ACTION_DOWN:
					if (goToEnd) {
						goToEnd = false;
					} else {
						goToEnd = true;
					}
					break;
			}
			return true;
		}
	};
	private String text;
	private TextToSpeech tts;
	private long LOCATION_REFRESH_TIME = 1;
	private long LOCATION_REFRESH_DISTANCE = 1;
	private String loc;
	private String DATE="";

	private boolean haveNetworkConnection() {
		boolean WIFI = false, CELLULAR = false;
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo[] netInfo = cm.getAllNetworkInfo();
		for (NetworkInfo ni : netInfo) {
			if (ni.getTypeName().equalsIgnoreCase("WIFI")) {
				if (ni.isConnected()) {
					WIFI = true;
				}
			}
			if (ni.getTypeName().equalsIgnoreCase("MOBILE")) {
				if (ni.isConnected()) {
					CELLULAR = true;
				}
			}
		}
		return WIFI || CELLULAR;
	}

	public void EmergencyMsg() {
		final String LocationLink ;
		final String patDetail = patientInfo();
		final double lt,lg;
		lt=LAT;
		lg=LNG;
		LocationLink = "http://maps.google.com/?q=" + lt + "," + lg;
		sendSMS("-- Patient's Emergency --\n\n" + patDetail + "\nCurrent Location: " + LocationLink);

	}
	public void RecoveryMsg(View view) {
		String patDetail = patientInfo();
		sendSMS("SUB: Recovered\n\n-- Patient Recovered --\n\n" + patDetail + "\n\nThankyou for considered my emergency...");
		stopRecording();

	}
	String patientInfo() {
		SaveUser su = new SaveUser(this);
		SharedPreferences sharedPreferences = getSharedPreferences(MyPreferences, Context.MODE_PRIVATE);
		String userName = sharedPreferences.getString(userPref, "");
		SQLiteDatabase db = su.getReadableDatabase();

		String dob = "", blood = "", gen = "", PatInfo = "";
		Cursor c = db.rawQuery("select dob,blood,gen from tbl_user where user = '" + userName + "'", null);
		if (c.moveToNext()) {
			dob = c.getString(c.getColumnIndex("dob"));
			blood = c.getString(c.getColumnIndex("blood"));
			gen = c.getString(c.getColumnIndex("gen"));

		}

		PatInfo += "Name: " + userName + "\nDOB: " + dob + "\nBlood Group: " + blood + "\nGender: " + gen;


		return PatInfo;

	}

	void sendSMS(String txt) {

		String ph1="",ph2="";
		SaveUser su = new SaveUser(this);
		SharedPreferences sharedPreferences = getSharedPreferences(MyPreferences, Context.MODE_PRIVATE);
		String userName = sharedPreferences.getString(userPref, "");
		SQLiteDatabase db = su.getReadableDatabase();

		String dob = "", blood = "", gen = "", PatInfo = "";
		Cursor c = db.rawQuery("select ph1,ph2 from tbl_user where user = '" + userName + "'", null);
		if (c.moveToNext()) {
			ph1 = c.getString(c.getColumnIndex("ph1"));
			ph2 = c.getString(c.getColumnIndex("ph2"));

		}

		MessageText = txt;
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
			if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
				ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 0);
			} else {
				ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 0);
			}
		} else {

			SmsManager smsManager = SmsManager.getDefault();
//			smsManager.sendTextMessage(new String(";9944627468;9003951807;"), null, MessageText, null, null);
			smsManager.sendTextMessage(new String(ph1), null, MessageText, null, null);
			smsManager.sendTextMessage(new String(ph2), null, MessageText, null, null);
			Toast.makeText(classContext, "Message Sent Successfully!", Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 0) {
			if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
				SmsManager smsManager = SmsManager.getDefault();//SARAVAN SIR:  +918072172214
				smsManager.sendTextMessage("+919944627468", null, MessageText, null, null);
			//	smsManager.sendTextMessage(new String (ph2), null, MessageText, null, null);
				Toast.makeText(classContext, "Message sent successfully!", Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(classContext, "SMS Failed!!!", Toast.LENGTH_SHORT).show();
			}
		}
	}

	@Override
	public void onLocationChanged(Location location) {

		toastCount++;

		if(toastCount==1){

			LAT=location.getLatitude();
			LNG=location.getLongitude();
			loc=LAT+","+LNG;
				Toast.makeText(classContext, "Latitude: "+LAT+" & Longtitude: "+LNG, Toast.LENGTH_SHORT).show();
			DatePicker dp=new DatePicker(this);
		}Log.d("####onLocationChanged ","Lat: "+location.getLatitude()+" & Long: "+location.getLongitude());

	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {

	}

	@Override
	public void onProviderEnabled(String provider) {

	}

	@Override
	public void onProviderDisabled(String provider) {

	}


	/**
	 * Handler that receives messages from the service. It receives frames data,
	 * error messages and a saved message if service stops correctly
	 *
	 */

	@SuppressLint("HandlerLeak")
	class IncomingHandler extends Handler {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
				case BiopluxService.MSG_DATA: {
					appendDataToGraphs(
							msg.getData().getDouble(BiopluxService.KEY_X_VALUE),
							msg.getData().getShortArray(BiopluxService.KEY_FRAME_DATA));
					break;
				}
				case BiopluxService.MSG_CONNECTION_ERROR: {
					serviceError = true;
					savingDialog.dismiss();
					displayConnectionErrorDialog(msg.arg1);
					break;
				}
				case DataManager.MSG_PERCENTAGE: {
					if (!savingDialogMessageChanged && msg.arg2 == DataManager.STATE_COMPRESSING_FILE) {
						savingDialog.setMessage(getString(R.string.nr_saving_dialog_compressing_message));
						savingDialogMessageChanged = true;
					}
					savingDialog.setProgress(msg.arg1);

					break;
				}
				case BiopluxService.MSG_SAVED: {
					savingDialog.dismiss();
					saveRecordingOnInternalDB();
					if (closeRecordingActivity) {
						closeRecordingActivity = false;
						finish();
						overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
					}
					displayInfoToast(getString(R.string.nr_info_rec_saved));
					break;
				}
				default: {
					super.handleMessage(msg);
				}
			}
		}
	}

	/**
	 * Bind connection used to bind and unbind with service
	 * onServiceConnected() called when the connection with the service has been established,
	 * giving us the object we can use to interact with the service. We are
	 * communicating with the service using a Messenger, so here we get a
	 * client-side representation of that from the raw IBinder object.
	 */
	private ServiceConnection bindConnection = new ServiceConnection() {

		public static final String MyPreferences = "MyBioPref";
		public static final String userPref = "userPref";

		public void onServiceConnected(ComponentName className, IBinder service) {
			serviceMessenger = new Messenger(service);
			isServiceBounded = true;
			Message msg = Message.obtain(null, BiopluxService.MSG_REGISTER_CLIENT);
			msg.replyTo = activityMessenger;
			try {
				serviceMessenger.send(msg);
			} catch (RemoteException e) {
				Log.e(TAG, "service conection failed", e);
				displayConnectionErrorDialog(10); // 10 -> fatal error
			}
		}

		/**
		 *  This is called when the connection with the service has been
		 *  unexpectedly disconnected -- that is, its process crashed.
		 */
		public void onServiceDisconnected(ComponentName className) {
			serviceMessenger = null;
			isServiceBounded = false;
			Log.i(TAG, "service disconnected");
		}
	};

	/**
	 * Appends x and y values received from service to all active graphs. The
	 * graph always moves to the last value added
	 */
	void appendDataToGraphs(double xValue, short[] data) {
		if (!serviceError) {
			for (int i = 0; i < graphs.length; i++) {
				graphs[i].getSerie().appendData(
						new GraphViewData(xValue,
								data[displayChannelPosition[i]]), goToEnd, maxDataCount);
			}
		}
	}

	/**
	 * Sends recording duration to the service by message when recording is
	 * stopped
	 */
	private void sendRecordingDuration() {
		if (isServiceBounded && serviceMessenger != null) {
			Message msg = Message.obtain(null, BiopluxService.MSG_RECORDING_DURATION, 0, 0);
			Bundle extras = new Bundle();
			extras.putString(KEY_DURATION, duration);
			msg.setData(extras);
			msg.replyTo = activityMessenger;
			try {
				serviceMessenger.send(msg);
			} catch (RemoteException e) {
				Log.e(TAG, "Error sending duration to service", e);
				displayConnectionErrorDialog(10); // 10 -> fatal error
			}
		} else {
			Log.e(TAG, "Error sending duration to service");
		}
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ly_new_recording);

		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

		if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.ACCESS_FINE_LOCATION)){

	Toast.makeText(classContext, "Location Permission not granted !", Toast.LENGTH_SHORT).show();
}else{
ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},0);
}
			locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
		}
else{
			locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
		}
final ProgressDialog progressDialog=new ProgressDialog(NewRecordingActivity.this);
progressDialog.setMessage("Configuring...");
progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
final DatePicker dp=new DatePicker(this);
	//DATE=dp.getDayOfMonth()+"/"+dp.getMonth()+"/"+dp.getYear();
	//	final SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/YYYY HH:mm:ss a");
progressDialog.setCancelable(false);
		progressDialog.show();
new Thread(new Runnable() {
	@Override
	public void run() {
		try {

			Thread.sleep(5000);

		}catch (Exception e){
			e.printStackTrace();
		}

		if (toastCount<1){
			loc="Location not available!";
		}
		progressDialog.dismiss();

		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss a");
		Log.e("DATE ERROR",sdf.format(new Date()).toString());
		SaveUser su=new SaveUser(getApplicationContext());
		if(su.getStatus()%2!=0){
			SharedPreferences sharedPreferences=getSharedPreferences(MyPreferences,Context.MODE_PRIVATE);
//			su.setEpiTime(sharedPreferences.getString(userPref,""),dp.getDayOfMonth()+"/"+(dp.getMonth()+1)+"/"+dp.getYear());
			su.setEpiTime(sharedPreferences.getString(userPref,""),sdf.format(new Date()).toString());

		}

	}
}).start();

		Recovered=(Button)findViewById(R.id.RECOVERED);

		Recovered.setEnabled(false);
		Log.i(TAG, "onCreate()");




		// GETTING EXTRA INFO FROM INTENT
		extras = getIntent().getExtras();
		recordingConfiguration = (DeviceConfiguration) extras.getSerializable(ConfigurationsActivity.KEY_CONFIGURATION);
		recording = new DeviceRecording();
		recording.setName(extras.getString(ConfigurationsActivity.KEY_RECORDING_NAME).toString());
		//here set the userId to recodings####################
		SharedPreferences sharedPreferences=getSharedPreferences(MyPreferences,Context.MODE_PRIVATE);
recording.setUserId(sharedPreferences.getString(userPref,""));
		// INIT GLOBAL VARIABLES
		savingDialog = new ProgressDialog(classContext);
		savingDialog.setTitle(getString(R.string.nr_saving_dialog_title));
		savingDialog.setMessage(getString(R.string.nr_saving_dialog_adding_header_message)); 
		savingDialog.setCancelable(false);
		savingDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		savingDialog.setProgress(0); //starts with 0%
		savingDialog.setMax(100); //100%
		
		inflater = this.getLayoutInflater();
		sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
		currentZoomValue = Integer.valueOf(sharedPref.getString(SettingsActivity.KEY_PREF_ZOOM_VALUE, "150"));
		graphs = new Graph[recordingConfiguration.getDisplayChannelsNumber()];
		

		// Used to update zoom values
		SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
		settings.registerOnSharedPreferenceChangeListener(this);
		
		// calculates the display channel position of frame received
		displayChannelPosition = new int[recordingConfiguration.getDisplayChannels().size()];
		int displayIterator = 0;
		for(int i=0; i < recordingConfiguration.getActiveChannels().size(); i++){
			if(recordingConfiguration.getActiveChannels().get(i) == recordingConfiguration.getDisplayChannels().get(displayIterator)){
				displayChannelPosition[displayIterator] = i;
				if(displayIterator < (recordingConfiguration.getDisplayChannels().size()-1))
				displayIterator++;
			}
		}
		
		// INIT ANDROID' WIDGETS
		uiRecordingName = (TextView) findViewById(R.id.nr_txt_recordingName);
		uiRecordingName.setText(recording.getName());
		uiMainbutton = (Button) findViewById(R.id.nr_bttn_StartPause);
		chronometer = new Chronometer(classContext);
		
		initActivityContentLayout();
		
		// SETUP DIALOG
		setupConnectionErrorDialog();
	}
	
	
	
	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		Log.i(TAG, "onRestoreInstanceState");
		if (isServiceRunning()) {
			chronometer.setBase(savedInstanceState.getLong(KEY_CHRONOMETER_BASE));
			chronometer.start();
			uiMainbutton.setText(getString(R.string.nr_button_stop));
		}
		super.onRestoreInstanceState(savedInstanceState);
	}

	@Override
	protected void onResume() {
		// If service is running re-bind to it to send recording duration
		if (isServiceRunning()) {
			bindToService();
		}
		super.onResume();
		Log.i(TAG, "onResume()");
	}

	private void initActivityContentLayout() {
		
		LayoutParams graphParams, detailParameters;
		View graphsView = findViewById(R.id.nr_graphs);
		
		// Initializes layout parameters
		graphParams = new LayoutParams(LayoutParams.MATCH_PARENT,
				Integer.parseInt((getResources()
						.getString(R.string.graph_height))));
		detailParameters = new LayoutParams(LayoutParams.MATCH_PARENT,
				LayoutParams.WRAP_CONTENT);

		
			for (int i = 0; i < recordingConfiguration
					.getDisplayChannelsNumber(); i++) {
				graphs[i] = new Graph(this,
						getString(R.string.nc_dialog_channel)
								+ " "
								+ recordingConfiguration.getDisplayChannels()
										.get(i).toString());
				LinearLayout graph = (LinearLayout) inflater.inflate(
						R.layout.in_ly_graph, null);
				graphs[i].getGraphView().setOnTouchListener(graphTouchListener);
				((ViewGroup) graph).addView(graphs[i].getGraphView());
				((ViewGroup) graphsView).addView(graph, graphParams);
			}
		

		// If just one channel is being displayed, show configuration details
		if (recordingConfiguration.getDisplayChannelsNumber() == 1) {
			View details = inflater.inflate(R.layout.in_ly_graph_details, null);
			((ViewGroup) graphsView).addView(details, detailParameters);
			
			// get views
			uiConfigurationName = (TextView) findViewById(R.id.nr_txt_configName);
			uiNumberOfBits = (TextView) findViewById(R.id.nr_txt_config_nbits);
			uiReceptionFrequency = (TextView) findViewById(R.id.nr_reception_freq);
			uiSamplingFrequency = (TextView) findViewById(R.id.nr_sampling_freq);
			uiActiveChannels = (TextView) findViewById(R.id.nr_txt_channels_active);
			uiMacAddress = (TextView) findViewById(R.id.nr_txt_mac);

			// fill them
			uiConfigurationName.setText(recordingConfiguration.getName());
			uiReceptionFrequency.setText(String.valueOf(recordingConfiguration
					.getVisualizationFrequency()) + " Hz");
			uiSamplingFrequency.setText(String.valueOf(recordingConfiguration
					.getSamplingFrequency()) + " Hz");
			uiNumberOfBits.setText(String.valueOf(recordingConfiguration
					.getNumberOfBits()) + " bits");
			uiMacAddress.setText(recordingConfiguration.getMacAddress());
			uiActiveChannels.setText(recordingConfiguration.getActiveChannels()
					.toString());
		}
	}
	
	/**
	 * called when the back button is pressed and the recording is still
	 * running. On positive click, Stops and saves the recording, finishes
	 * activity so that parent gets focus
	 */
	private void showBackDialog() {
		// Sets a custom title view
		TextView customTitleView = (TextView) inflater.inflate(R.layout.dialog_custom_title, null);
		customTitleView.setText(R.string.nr_back_dialog_title);
		customTitleView.setBackgroundColor(getResources().getColor(R.color.waring_dialog));
		
		// dialog builder
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setCustomTitle(customTitleView)
				.setView(inflater.inflate(R.layout.dialog_newrecording_backbutton_content, null))
				.setPositiveButton(
						getString(R.string.nr_back_dialog_positive_button),
						new DialogInterface.OnClickListener() {
							// stops, saves and finishes recording
							public void onClick(DialogInterface dialog, int id) {
								stopRecording();
								closeRecordingActivity = true;
								// dialog gets closed
							}
						});
		builder.setNegativeButton(
				getString(R.string.nc_dialog_negative_button),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						// dialog gets closed
					}
				});

		AlertDialog backDialog = builder.create();
		backDialog.show();

	}

	/**
	 * Creates and shows a bluetooth error dialog if mac address is other than
	 * 'test' and the bluetooth adapter is turned off. On positive click it
	 * sends the user to android' settings for the user to turn bluetooth on
	 * easily
	 */
	private void showBluetoothDialog() {
		// Initializes custom title
		TextView customTitleView = (TextView) inflater.inflate(R.layout.dialog_custom_title, null);
		customTitleView.setText(R.string.nr_bluetooth_dialog_title);
		customTitleView.setBackgroundColor(getResources().getColor(R.color.error_dialog));
		
		// dialogs builder
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setCustomTitle(customTitleView)
				.setMessage(getResources().getString(R.string.nr_bluetooth_dialog_message))
				.setPositiveButton(getString(R.string.nr_bluetooth_dialog_positive_button),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						Intent intentBluetooth = new Intent();
						intentBluetooth.setAction(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
						classContext.startActivity(intentBluetooth);
					}
				});
		builder.setNegativeButton(
				getString(R.string.nc_dialog_negative_button),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						// dialog gets closed
					}
				});

		// creates and shows bluetooth dialog
		(builder.create()).show();
	}
	
	/**
	 * Sets up a connection error dialog with custom title. This is used to add
	 * custom message '.setMessage()' and display different possible connection
	 * errors it '.show()'
	 * 
	 */
	private void setupConnectionErrorDialog() {
		
		// Initializes custom title
		TextView customTitleView = (TextView) inflater.inflate(R.layout.dialog_custom_title, null);
		customTitleView.setText(R.string.nr_bluetooth_dialog_title);
		customTitleView.setBackgroundColor(getResources().getColor(R.color.error_dialog));
		
		// builder
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setCustomTitle(customTitleView)
			   .setPositiveButton(
				getString(R.string.bp_positive_button),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						savingDialog.dismiss();
						closeRecordingActivity = true;
						
					}
				});
		connectionErrorDialog = builder.create();
		connectionErrorDialog.setCancelable(false);
		connectionErrorDialog.setCanceledOnTouchOutside(false);
		
	}

	/**
	 * Called when 'start recording' button is twice pressed On positive click,
	 * the current recording is removed and graph variables and views are reset.
	 * The overwrite recording starts right away
	 * 
	 */
	private void showOverwriteDialog() {
		
		// initializes custom title view
		TextView customTitleView = (TextView) inflater.inflate(R.layout.dialog_custom_title, null);
		customTitleView.setText(R.string.nr_overwrite_dialog_title);
		customTitleView.setBackgroundColor(getResources().getColor(R.color.waring_dialog));
		
		// dialog' builder
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setCustomTitle(customTitleView)
				.setMessage(R.string.nr_overwrite_dialog_message)
				.setPositiveButton(
						getString(R.string.nr_overwrite_dialog_positive_button),
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								// deletes current recording from Android's internal Database
								try {
									Dao<DeviceRecording, Integer> dao = getHelper().getRecordingDao();
									dao.delete(recording);
								} catch (SQLException e) {
									Log.e(TAG, "saving recording exception", e);
								}
								
								// Reset activity variables
								recordingOverride = false;
								serviceError = false;
								closeRecordingActivity = false;
								savingDialogMessageChanged = false;
								goToEnd = true;
								
								// Reset activity content
								View graphsView = findViewById(R.id.nr_graphs);
								((ViewGroup) graphsView).removeAllViews();
								initActivityContentLayout();
								savingDialog.setMessage(getString(R.string.nr_saving_dialog_adding_header_message));
								savingDialog.setProgress(0);
								
								startRecording();
							}
						});
		builder.setNegativeButton(
				getString(R.string.nc_dialog_negative_button),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						// dialog gets closed
					}
				});

		(builder.create()).show();
	}

	/**
	 * If recording is running, shows save and quit confirmation dialog. If
	 * service is stopped. destroys activity
	 */
	@Override
	public void onBackPressed() {
		if (isServiceRunning())
			showBackDialog();
		else {
			super.onBackPressed();
			overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
		}
	}

	/**
	 * Stops and saves the recording in database and data as zip file
	 */
	private void stopRecording(){
		if(tts.isSpeaking()) {
			tts.stop();
			tts.shutdown();
		}
		savingDialog.show();
		stopChronometer();

		sendRecordingDuration();
		unbindFromService();
		stopService(new Intent(NewRecordingActivity.this, BiopluxService.class));
		uiMainbutton.setText(getString(R.string.nr_button_start));
		drawState = true;
	}
	
	/**
	 * Starts the recording if mac address is 'test' and recording is not
	 * running OR if bluetooth is supported by the device, bluetooth is enabled,
	 * mac is other than 'test' and recording is not running. Returns always
	 * false for the main thread to be stopped and thus be available for the
	 * progress dialog  spinning circle when we test the connection
	 */

	private boolean startRecording() {



		final SaveUser su=new SaveUser(classContext);
su.getReadableDatabase();
if(su.getStatus()%2!=0){

			EmergencyMsg();


Recovered.setEnabled(true);
}else{
	Recovered.setEnabled(false);

}
		BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		final ProgressDialog progress;
		tts=new TextToSpeech(NewRecordingActivity.this, new TextToSpeech.OnInitListener() {

			@Override
			public void onInit(int status) {
				// TODO Auto-generated method stub
				if(status == TextToSpeech.SUCCESS){
					int result=tts.setLanguage(Locale.US);
					if(result==TextToSpeech.LANG_MISSING_DATA ||
							result==TextToSpeech.LANG_NOT_SUPPORTED){
						Log.e("error", "This Language is not supported");
					}
					else{
						try {
							Thread.sleep(2000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						ConvertTextToSpeech(su.getStatus());
					}
				}
				else
					Log.e("error", "Initilization Failed!");
			}
		});
		if(recordingConfiguration.getMacAddress().compareTo("test")!= 0){ // 'test' is used to launch device emulator
			if (mBluetoothAdapter == null) {
				displayInfoToast(getString(R.string.nr_bluetooth_not_supported));
				return false;
			}
			if (!mBluetoothAdapter.isEnabled()){
				showBluetoothDialog();
				return false;
			}
		}

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		progress = ProgressDialog.show(this,getResources().getString(R.string.nr_progress_dialog_title),getResources().getString(R.string.nr_progress_dialog_message), true);
		Thread connectionThread = 
				new Thread(new Runnable() {
			@Override
			public void run() {
				
				//Revisar		BitalinoAndroidDevice connectionTest = new BitalinoAndroidDevice(recordingConfiguration.getMacAddress()); 
					//Revisar
					//Revisar					connectionTest.Close();
				
				
				runOnUiThread(new Runnable(){
				    public void run(){
				    	progress.dismiss();
						if(connectionError){
							displayConnectionErrorDialog(bpErrorCode);
						}else{
							Intent intent = new Intent(classContext, BiopluxService.class);
							intent.putExtra(KEY_RECORDING_NAME, recording.getName());
							intent.putExtra(KEY_CONFIGURATION, recordingConfiguration);
							startService(intent);
							bindToService();
							startChronometer();
							uiMainbutton.setText(getString(R.string.nr_button_stop));
							displayInfoToast(getString(R.string.nr_info_started));
							drawState = false;

							//create timer task to increment counter
							TimerTask timerTask = new TimerTask() {

								@Override
								public void run() {
									// System.out.println("TimerTask executing counter is: " + counter);
									counter++;
								}
							};


							//create thread to print counter value
							 Thread t = new Thread(new Runnable() {

								@SuppressLint("ResourceAsColor")
								@Override
								public void run() {
									while (true) {
										try {
											System.out.println("Thread reading counter is: " + counter);
											if (counter%3 == 0&&counter!=0) {
													ConvertTextToSpeech(su.getStatus());
									}
											Thread.sleep(3000);
										} catch (InterruptedException ex) {
											ex.printStackTrace();
										}
									}
								}
							});

							timer = new Timer("MyTimer");//create a new timer
							timer.scheduleAtFixedRate(timerTask, 30, 3000);//start timer in 30ms to increment  counter

							t.start();//start thread to display counter
							//dialog.show();
						}
				    }
				});
			}
		});
		
		if(recordingConfiguration.getMacAddress().compareTo("test")==0 && !isServiceRunning() && !recordingOverride)
			connectionThread.start();
		else if(mBluetoothAdapter.isEnabled() && !isServiceRunning() && !recordingOverride) {
			connectionThread.start();
		}
		return false;
	}
	
	/**
	 * Displays an error dialog with corresponding message based on the
	 * errorCode it receives. If code is unknown it displays FATAL ERROR message
	 */
	private void displayConnectionErrorDialog(int errorCode) {
		// Initializes custom title
		TextView customTitleView = (TextView) inflater.inflate(R.layout.dialog_custom_title, null);
		customTitleView.setBackgroundColor(getResources().getColor(R.color.error_dialog));
		switch(errorCode){
		case 1:
			connectionErrorDialog.setMessage(getResources().getString(R.string.bp_address_incorrect));
			break;
		case 2:
			connectionErrorDialog.setMessage(getResources().getString(R.string.bp_adapter_not_found));
			break;
		case 3:
			connectionErrorDialog.setMessage(getResources().getString(R.string.bp_device_not_found));
			break;
		case 4:
			connectionErrorDialog.setMessage(getResources().getString(R.string.bp_contacting_device));
			break;
		case 5:
			connectionErrorDialog.setMessage(getResources().getString(R.string.bp_port_could_not_be_opened));
			break;
		case 6:
			customTitleView.setText(R.string.nr_storage_error_dialog_title);
			connectionErrorDialog.setCustomTitle(customTitleView);
			connectionErrorDialog.setMessage(getResources().getString(R.string.bp_error_writing_a_frame));
			break;
		case 7:
			customTitleView.setText(R.string.nr_storage_error_dialog_title);
			connectionErrorDialog.setCustomTitle(customTitleView);
			connectionErrorDialog.setMessage(getResources().getString(R.string.bp_error_saving_recording));
			break;
		default:
			connectionErrorDialog.setMessage("FATAL ERROR");
			break;
		}
		connectionErrorDialog.show();
	}

	/**
	 * Displays a custom view information toast with the message it receives as
	 * parameter
	 */
	private void displayInfoToast(String messageToDisplay) {
		Toast infoToast = new Toast(classContext);
		View toastView = inflater.inflate(R.layout.toast_info, null);
		infoToast.setView(toastView);
		((TextView) toastView.findViewById(R.id.display_text)).setText(messageToDisplay);
		infoToast.show();
	}
	
	/**
	 * Starts Android' chronometer widget to display the recordings duration
	 */
	private void startChronometer() {
		chronometer.setBase(SystemClock.elapsedRealtime());
		chronometer.start();
	}

	/**
	 * Stops the chronometer and calculates the duration of the recording
	 */
	private void stopChronometer() {
		chronometer.stop();
		long elapsedMiliseconds = SystemClock.elapsedRealtime()
				- chronometer.getBase();
		duration = String.format("%02d:%02d:%02d",
				(int) ((elapsedMiliseconds / (1000 * 60 * 60)) % 24), 	// hours
				(int) ((elapsedMiliseconds / (1000 * 60)) % 60),	  	// minutes
				(int) (elapsedMiliseconds / 1000) % 60);				// seconds
	}

	/**
	 * Saves the recording on Android's internal Database with ORMLite
	 */
	public void saveRecordingOnInternalDB() {
		DateFormat dateFormat = DateFormat.getDateTimeInstance();
		Date date = new Date();

		recording.setConfiguration(recordingConfiguration);
		recording.setSavedDate(dateFormat.format(date));
		recording.setDuration(duration);
		try {
			Dao<DeviceRecording, Integer> dao = getHelper().getRecordingDao();
			dao.create(recording);
		} catch (SQLException e) {
			Log.e(TAG, "saving recording exception", e);
			displayConnectionErrorDialog(10); // 10 -> fatal error
		}
	}

	/**
	 * Gets all the processes that are running on the OS and checks whether the
	 * bioplux service is running. Returns true if it is running and false
	 * otherwise
	 */
	private boolean isServiceRunning() {
		ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (BiopluxService.class.getName().equals(service.service.getClassName()) && service.restarting == 0) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Attaches connection with the service and passes the recording name and
	 * the correspondent configuration to it on its intent
	 */
	void bindToService() {
		Intent intent = new Intent(classContext, BiopluxService.class);
		bindService(intent, bindConnection, 0);
	}

	/**
	 * Detach our existing connection with the service
	 */
	void unbindFromService() {
		if (isServiceBounded) {
			unbindService(bindConnection);
			isServiceBounded = false;
		}
	}
	
	/**
	 * Main button of activity. Starts, overwrites and stops recording depending
	 * of whether the recording was never started, was started or was started
	 * and stopped
	 */
	public void onMainButtonClicked(View view) {
		// Starts recording
		if (!isServiceRunning() && !recordingOverride) {
			startRecording();
		// Overwrites recording
		} else if (!isServiceRunning() && recordingOverride) {
			showOverwriteDialog();
		// Stops recording
		} else if (isServiceRunning()) {
			recordingOverride = true;
			stopRecording();
		}
	}
	
	/************************  EVENTS **********************/
	
	public void onClikedMenuItems(View v) {
	    PopupMenu popup = new PopupMenu(this, v);
	    popup.setOnMenuItemClickListener(this);
	    MenuInflater inflater = popup.getMenuInflater();
	    inflater.inflate(R.menu.new_recording_menu, popup.getMenu());
	    popup.show();
	}
	
	@Override
	public boolean onMenuItemClick(MenuItem item) {
	    // Handle item selection
	    switch (item.getItemId()) {
	        case R.id.nr_settings:
	        	Intent recordingSettingsIntent = new Intent(this, SettingsActivity.class);
	        	recordingSettingsIntent.putExtra(Constants.KEY_SETTINGS_TYPE, 2);
	        	recordingSettingsIntent.putExtra(Constants.KEY_SETTINGS_DRAW_STATE, drawState);
	        	startActivity(recordingSettingsIntent);
	            return true;
	        case R.id.nr_restore_zoom:
	        	long startValue = 0;
	        	for (int i = 0; i < graphs.length; i++){
	        		if(graphs[i].getxValue() - Long.valueOf(getResources().getString(
							R.string.graph_viewport_size)) < Long.valueOf(getResources().getString(
							R.string.graph_viewport_size)))
	        			startValue = graphs[i].getxValue();
	        		else
	        			startValue = graphs[i].getxValue() - Long.valueOf(getResources().getString(
								R.string.graph_viewport_size));
	        			
	        		graphs[i].getGraphView().setViewPort(startValue, Long.valueOf(getResources().getString(
							R.string.graph_viewport_size)));
	        		graphs[i].getGraphView().redrawAll();
	        	}
	    			
	        	return true;
	        default:
	            return super.onOptionsItemSelected(item);
	    }
	}

	public void onSharedPreferenceChanged(SharedPreferences sharedPreferences,
			String key) {
		if(key.compareTo(SettingsActivity.KEY_PREF_ZOOM_VALUE) == 0)
			currentZoomValue = Integer.valueOf(sharedPref.getString(SettingsActivity.KEY_PREF_ZOOM_VALUE, "150"));
	}

	/**
	 * Widens the graphs' view port
	 */
	public void zoomIn(View view){
		for (int i = 0; i < graphs.length; i++)
			graphs[i].getGraphView().zoomIn(currentZoomValue); 
	}
	
	/**
	 * Shortens the graphs' view port
	 */
	public void zoomOut(View view){
		double zoomOutValue = 66.6;
		if(currentZoomValue == 200)
			zoomOutValue = 50;
		else if(currentZoomValue == 300)
			zoomOutValue = 33.3;
		else if(currentZoomValue == 400)
			zoomOutValue = 25;
		for (int i = 0; i < graphs.length; i++)
			graphs[i].getGraphView().zoomOut(zoomOutValue); 
	}
	
	
	@Override
	protected void onPause() {
		if(tts != null){

			tts.stop();
			tts.shutdown();
		}
		try {
			unbindFromService();
		} catch (Throwable t) {
			Log.e(TAG, "failed to unbind from service when activity is destroyed", t);
			displayConnectionErrorDialog(10); // 10 -> fatal error
		}
		super.onPause();
		Log.i(TAG, "onPause()");
	}
	

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		Log.i(TAG, "onSavedInstance");
		outState.putLong(KEY_CHRONOMETER_BASE, chronometer.getBase());
		super.onSaveInstanceState(outState);
	}

	/**
	 * Destroys activity
	 */
	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.i(TAG, "onDestroy()");
	}
	private void ConvertTextToSpeech(int n) {
		// TODO Auto-generated method stub

		if(n<=0&&n!=-10)
		{
			text = "Content not available";
			tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
		}
		else if(n==-10){
			tts.speak("Hi buddy...", TextToSpeech.QUEUE_FLUSH, null);
		}
		else {
if(n%2==0){
	Toast.makeText(getApplicationContext(),"Normal",Toast.LENGTH_SHORT).show();
	//tts.speak("Message: you are normal!", TextToSpeech.QUEUE_FLUSH, null);
}
else{
	Toast.makeText(getApplicationContext(),"Warning: Epillepsy, Be Alert!!!",Toast.LENGTH_SHORT).show();
	//tts.speak("Warning: Epillepsy, Be Alert!!!", TextToSpeech.QUEUE_FLUSH, null);
}

		}
	}
}
