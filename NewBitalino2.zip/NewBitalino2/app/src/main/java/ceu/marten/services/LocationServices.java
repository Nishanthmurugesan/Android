package ceu.marten.services;

import android.Manifest;
import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by ace on 19-Aug-18.
 */

public class LocationServices extends Service implements LocationListener {
    String loc;
    LocationManager locationManager;
    @Override
    public void onLocationChanged(Location location) {
        loc=location.getLatitude()+","+location.getLongitude();
Log.d("#####LocationService",loc);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if(ActivityCompat.shouldShowRequestPermissionRationale((Activity) getApplicationContext(),Manifest.permission.ACCESS_FINE_LOCATION)){

                Toast.makeText((Activity) getApplicationContext(), "Location Permission not granted !", Toast.LENGTH_SHORT).show();
            }else{
                ActivityCompat.requestPermissions((Activity) getApplicationContext(),new String[]{Manifest.permission.ACCESS_FINE_LOCATION},0);
            }
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public LocationServices() {

    }

    public String getLocation() {

           try {

               while (loc==null){
                   Thread.sleep(1);
               }
           }catch (Exception e){
               e.printStackTrace();
           }

  return loc;
}
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
