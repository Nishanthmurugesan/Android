package ceu.marten.ui;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.ace.newbitalino.SaveUser;

import java.util.ArrayList;

import ceu.marten.bitadroid.R;

public class PatReportList extends AppCompatActivity {
ListView patList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pat_report_list);
        patList=(ListView)findViewById(R.id.PatList);
        ArrayList<String> arrayList=new ArrayList<>();
        SaveUser su=new SaveUser(this);
        SQLiteDatabase db=su.getReadableDatabase();
        Cursor c=db.rawQuery("select user from tbl_user",null);
    while (c.moveToNext()){
        arrayList.add(c.getString(c.getColumnIndex("user")));
    }
    db.close();
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrayList);
        patList.setAdapter(arrayAdapter);
        patList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Bundle bundle=new Bundle();
                bundle.putString("PATIENT", String.valueOf(parent.getItemAtPosition(position)));
                Intent intent=new Intent(PatReportList.this,PatReport.class);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });
    }

}
