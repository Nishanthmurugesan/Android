package ceu.marten.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ace.newbitalino.SaveUser;

import ceu.marten.bitadroid.R;

public class Login extends AppCompatActivity {

    EditText user,pass;
    SharedPreferences sharedPreferences;
    public  static final String MyPreferences="MyBioPref";
    public  static final String userPref="userPref";
    public  static final String passPref="passPref";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        user= (EditText) findViewById(R.id.user);
        pass= (EditText) findViewById(R.id.pass);
        sharedPreferences=getSharedPreferences(MyPreferences, Context.MODE_PRIVATE);
    }

    public void login(View view) {
        SaveUser su=new SaveUser(this);
        View parentLayout= findViewById(android.R.id.content);
        if(!user.getText().toString().isEmpty()&&!pass.getText().toString().isEmpty()){
           if(su.loginCheck(user.getText().toString(),pass.getText().toString())>0){
                    String uname=user.getText().toString(), pwd=pass.getText().toString();
                    SharedPreferences.Editor editor=sharedPreferences.edit();
                    editor.putString(userPref,uname);
                    editor.putString(passPref,pwd);

                    editor.commit();
                    Intent intent=new Intent(this,HomeActivity.class);
                    startActivity(intent);
                    finish();
                    Snackbar.make(parentLayout,"Login Successfully!",Snackbar.LENGTH_LONG).show();
                    Toast.makeText(this, "Welcome "+uname+" !", Toast.LENGTH_SHORT).show();

                }else{
                   // Snackbar.make(parentLayout,"Invalid Username / Password!!!",Snackbar.LENGTH_LONG).show();
                    Toast.makeText(this, "Invalid Username / Password!!!", Toast.LENGTH_SHORT).show();

                }


        }else{
           // Snackbar.make(parentLayout,"Please give the input properly!!!",Snackbar.LENGTH_LONG).show();
            Toast.makeText(this, "Please give the input properly!!!", Toast.LENGTH_SHORT).show();
        }
    }
    public void login1(View view){

        View parentLayout1= findViewById(android.R.id.content);
        if(!user.getText().toString().isEmpty()&&!pass.getText().toString().isEmpty()){
        if(user.getText().toString().equals("Doctor")&&pass.getText().toString().equals("dr123")){
            String uname=user.getText().toString(),pwd=pass.getText().toString();
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putString(userPref,uname);
            editor.putString(passPref,pwd);

            editor.commit();
            Intent intent=new Intent(this,DrHome.class);
            startActivity(intent);
            finish();
            Toast.makeText(this, "Login Successfully!", Toast.LENGTH_SHORT).show();

        }else{
            //Snackbar.make(parentLayout1,"Invalid Username / Password!!!",Snackbar.LENGTH_LONG).show();
            Toast.makeText(this, "Invalid Username / Password!!!", Toast.LENGTH_SHORT).show();

        }


    }else{
        //Snackbar.make(parentLayout1,"Please give the input properly!!!",Snackbar.LENGTH_LONG).show();
        Toast.makeText(this, "Please give the input properly!!!", Toast.LENGTH_SHORT).show();
        }

    }


    public void GoToReg(View view) {
        Intent intent=new Intent(this,RegisterActivity.class);
        startActivity(intent);

    }
}








