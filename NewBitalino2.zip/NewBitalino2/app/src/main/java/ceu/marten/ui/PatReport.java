package ceu.marten.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.ace.newbitalino.SaveUser;
import com.jjoe64.graphview.CustomLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.LineGraphView;


import java.util.Random;

import ceu.marten.bitadroid.R;

public class PatReport extends AppCompatActivity {
String patUname,gen,dob,phone,blood,occur;
TextView pname,pgen,pdob,pPhone,pblood,pOccurance;

    private int lastX=0;
    private Random RANDOM;

    private GraphViewSeries basicSerie;
    private GraphViewSeries.GraphViewSeriesStyle style;
    private long xValue;
    private GraphView graphView,graphView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        RANDOM=new Random();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pat_report);
        Intent bundleData=getIntent();
       patUname=bundleData.getStringExtra("PATIENT");
       SaveUser su=new SaveUser(this);
        SQLiteDatabase db=su.getReadableDatabase();
        Cursor c=db.rawQuery("select gen,phone,blood,dob from tbl_user where user = '"+patUname+"'",null);
        if(c.getCount()>0){
            c.moveToNext();
            gen=c.getString(c.getColumnIndex("gen"));
            dob=c.getString(c.getColumnIndex("dob"));
            phone=c.getString(c.getColumnIndex("phone"));
            blood=c.getString(c.getColumnIndex("blood"));

        }
    occur=su.getEpiTime(patUname);
        pname=(TextView)findViewById(R.id.PNAME);
        pgen=(TextView)findViewById(R.id.GEN);
        pdob=(TextView)findViewById(R.id.DOB);
        pPhone=(TextView)findViewById(R.id.PHONE);
        pblood=(TextView)findViewById(R.id.BLOOD);
        pOccurance=(TextView)findViewById(R.id.OCCURANCE);
        pname.setText(pname.getText()+patUname);
        pgen.setText(pgen.getText()+gen);
        pdob.setText(pdob.getText()+dob);
        pPhone.setText(pPhone.getText()+phone);
        pblood.setText(pblood.getText()+blood);
        if(!occur.equalsIgnoreCase("null")){
            pOccurance.setText("Last Occurance: "+occur);
             graphView = (LineGraphView) findViewById(R.id.graph);

            // INIT SERIE DATA

            // INIT GRAPHVIEW


        }else{
            pOccurance.setText("Normal");
        }

    }


}
