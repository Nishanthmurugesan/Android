package ceu.marten.ui.adapters;

import java.util.ArrayList;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import ceu.marten.bitadroid.R;
import ceu.marten.model.DeviceRecording;

import com.haarman.listviewanimations.ArrayAdapter;

public class RecordingsListAdapter extends ArrayAdapter<DeviceRecording> {

	private final Context context;
	SharedPreferences sharedPreferences;
	public  static final String MyPreferences="MyBioPref";
	public  static final String userPref="userPref";

	public RecordingsListAdapter(Context context,
			ArrayList<DeviceRecording> recordings,SharedPreferences sharedPreferences) {
		super(recordings);
		this.context = context;
this.sharedPreferences=sharedPreferences;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewGroup rowView = (ViewGroup) convertView;
		if (rowView == null) {
			rowView = (ViewGroup) LayoutInflater.from(context).inflate(R.layout.li_recording, parent, false);
		}

		TextView name = (TextView) rowView.findViewById(R.id.dli_name);
		TextView date = (TextView) rowView.findViewById(R.id.dli_date);
		TextView duration = (TextView) rowView.findViewById(R.id.dli_duration);

		DeviceRecording recording = getItem(position);//here set list data as per userId
		String userId=recording.getUserId();
if(sharedPreferences.getString(userPref,"").equals(userId)){
	name.setText(recording.getName());
	date.setText(recording.getSavedDate());
	duration.setText(context.getString(R.string.ra_duration) + " " + recording.getDuration());

}

		return rowView;
	}

	@Override
	public long getItemId(int position) {
		return getItem(position).hashCode();
	}

	@Override
	public boolean hasStableIds() {
		return true;
	}

}