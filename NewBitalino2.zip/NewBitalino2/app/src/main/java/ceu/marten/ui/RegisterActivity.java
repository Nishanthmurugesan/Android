package ceu.marten.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.ace.newbitalino.SaveUser;

import java.util.ArrayList;

import ceu.marten.bitadroid.R;

public class RegisterActivity extends AppCompatActivity {
String DOB="";
EditText uname,pass,conf,phone,emg1,emg2;
Spinner bloodGrp;
RadioButton male,female;
Button dobBtn;

ArrayList<String> bld=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bld.add("A+");
        bld.add("B+");
        bld.add("A-");
        bld.add("B-");
        bld.add("AB+");
        bld.add("AB-");
        bld.add("O+");
        bld.add("O-");

        setContentView(R.layout.activity_register);
 uname =(EditText)findViewById(R.id.user);
 pass=(EditText)findViewById(R.id.pass);
 conf=(EditText)findViewById(R.id.confirm_pass);
 phone=(EditText)findViewById(R.id.phone);
 emg1=(EditText)findViewById(R.id.phone1);
 emg2=(EditText)findViewById(R.id.phone2);
 dobBtn=(Button)findViewById(R.id.DOB);
 male=(RadioButton)findViewById(R.id.MALE);
        female=(RadioButton)findViewById(R.id.FEMALE);
        bloodGrp=(Spinner)findViewById(R.id.BLOOD);
      ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,bld);
        bloodGrp.setAdapter(arrayAdapter);

    }
    public void setDOB(View view) {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("Set Date Of Birth");
        final DatePicker datePicker=new DatePicker(this);
        LinearLayout.LayoutParams layoutParams=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
   datePicker.setLayoutParams(layoutParams);

   builder.setView(datePicker);
builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
    @Override
    public void onClick(DialogInterface dialog, int which) {
        DOB=datePicker.getDayOfMonth()+"/"+(datePicker.getMonth()+1)+"/"+datePicker.getYear();
        dobBtn.setText(DOB);

    }
});
builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
    @Override
    public void onClick(DialogInterface dialog, int which) {
   dialog.dismiss();
    }
});
builder.show();
    }
    public void Register(View view) {
        SaveUser su=new SaveUser(this);
        String user,pwd,ph,ph1,ph2,dob,blood,gen;
      user=uname.getText().toString();
      pwd=pass.getText().toString();
      ph=phone.getText().toString();
      ph1 = phone.getText().toString();
      ph2=phone.getText().toString();
      dob=dobBtn.getText().toString();
      blood=bloodGrp.getSelectedItem().toString();
      if(male.isChecked()){
          gen="Male";
      }else{
          gen="Female";
      }
      if(!user.isEmpty()&&!pwd.isEmpty()&&!ph.isEmpty()&&!dob.equals("Set DOB")&&!blood.isEmpty()&&!ph1.isEmpty()&&!ph2.isEmpty()){
if(conf.getText().toString().equals(pwd)){
    if(ph.length()==10){
if(pass.length()>=5){
    int check=su.register(user,pwd,ph,dob,blood,gen,ph1,ph2);
    if(check==0){
        Toast.makeText(this,"Registeration Successfully!",Toast.LENGTH_LONG).show();
        Intent intent=new Intent(this,Login.class);
        startActivity(intent);
        finish();
    }else if(check ==1){
        uname.setError("User already exists...");
    }else{
        Toast.makeText(this,"Something went wrong!",Toast.LENGTH_LONG).show();
    }

}else{
    pass.setError("Password must have at least 5 chars");
}
    }else{
        phone.setError("Invalid Phone Number...");
    }

}else{
    pass.setError("Password Mismatching...");
}
      }else{
          uname.setError("Please fill all the details...");
      }
    }
}
