package ceu.marten.services;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by ace on 28-Aug-18.
 */

public class dateService
{
    SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/YYYY HH:mm:ss a");

    public String getSdf() {
        return sdf.format(new Date());
    }


}
