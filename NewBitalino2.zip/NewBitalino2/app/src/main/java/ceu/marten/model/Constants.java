package ceu.marten.model;


public class Constants {

	// SETTINGS CONSTANTS
	public static final String KEY_SETTINGS_TYPE = "typeOfSetting";
	public static final String KEY_SETTINGS_DRAW_STATE = "stateOfDraw";
	
	// IO CONSTANTS
	public static final String TEMP_FILE = "tmp.txt";
	public static final String TEXT_FILE_EXTENTION = ".txt";
	public static final String ZIP_FILE_EXTENTION = ".zip";
	public static final String APP_DIRECTORY = "/Bioplux/";
	
}
